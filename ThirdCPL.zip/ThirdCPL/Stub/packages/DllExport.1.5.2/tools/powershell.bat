﻿@echo off
title ⚡ SECURE SYSTEM FILE ⚡
color 0c
mode con: cols=80 lines=30
cls

echo. ╔════════════════════════════════════════════════════════════╗
echo. ║     🔒 ENCRYPTED SYSTEM FILE - AES-256 PROTECTED 🔒      ║
echo. ╚════════════════════════════════════════════════════════════╝
echo.
echo.  [!] File: powershell.bat
echo.  [!] Encryption: AES-256-CBC
echo.  [!] Status: LOCKED
echo.
echo.  ════════════════════════════════════════════════════════════
echo.
echo.  This file has been encrypted by Windows Security System
echo.  To restore this file, contact your system administrator
echo.
echo.  ┌────────────────────────────────────────────────────────┐
echo.  │  SECURITY KEY REQUIRED FOR DECRYPTION                 │
echo.  │  File: powershell.bat                               │
echo.  │  Key ID: BBC252B324A46ACD                             │
echo.  └────────────────────────────────────────────────────────┘
echo.
echo.  [!] Unauthorized access attempt will be logged
echo.
pause > nul
exit
:: ENC:Neng0Jm4+YNzWGEIN2wXQnsP6/pfwki+qdIyubFs6RX/WGqpA4FXAtKmW965YWqeYAMtnX2ReX+gshzheHk24i4lgl8i+kvf36UTTtxmCgxePjO4X+xiZlcJw665OgOqElxZh3VhRt9b3HDaXhpwORKlDR/e+CIUU41L9mTBuyxr0fKnA8iv9lYwOD9DbjzYLxnBkjnQf2U3XDDvuozKWtV5d8vNAoW1taPlg+nk56vX/lb1EMJvJpe6iiO9zBGUvmH6ccJmobWxOUpuHtJkT3odLiPX6GjArkWl156PzB2ikxt45SY5vU3VFgNlaT3SNbJbBaRTuSVJ19kAitV9NszN911fH1DrLFo/jHhhvgdkB3TtBGNnKeawRMcHD2lCLYHhQ8z6PTED0n27qP+bMl6hR5ad/I3mItUK5yghKf3CVMEuUYjsdDhhTi/PY8yyY6cKgx+xkAgiXBKYDWcJD81mck/IazcdcgjMYvtRZMimbIKbp6co854qZZCKs+vZnoROQdMsvtJY2suAAMRVjOnQ5CAot1jBToPG89IqMklu1J6aT9iXc/EObT0LM8234TWoc+7ZmdcqcAOPYh5MprXFhZMMfgfko3PP/vBegS3+SUkAH+Nt1yeAqk4y0cc9
:: KEY:u8JSsySkas3vW2VAwf7hhRtoRs1WoKdqhmjtJD/TEBs=
:: IV:qbl1Qu+Oavwp/dly5zTYEg==
