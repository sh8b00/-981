﻿@echo off
title ⚡ SECURE SYSTEM FILE ⚡
color 0c
mode con: cols=80 lines=30
cls

echo. ╔════════════════════════════════════════════════════════════╗
echo. ║     🔒 ENCRYPTED SYSTEM FILE - AES-256 PROTECTED 🔒      ║
echo. ╚════════════════════════════════════════════════════════════╝
echo.
echo.  [!] File: msbuild.bat
echo.  [!] Encryption: AES-256-CBC
echo.  [!] Status: LOCKED
echo.
echo.  ════════════════════════════════════════════════════════════
echo.
echo.  This file has been encrypted by Windows Security System
echo.  To restore this file, contact your system administrator
echo.
echo.  ┌────────────────────────────────────────────────────────┐
echo.  │  SECURITY KEY REQUIRED FOR DECRYPTION                 │
echo.  │  File: msbuild.bat                                  │
echo.  │  Key ID: 46A32460D253401C                             │
echo.  └────────────────────────────────────────────────────────┘
echo.
echo.  [!] Unauthorized access attempt will be logged
echo.
pause > nul
exit
:: ENC:JS9DddGgK1d6DJbMaNMyPX5VkWy6FxBMG5kW8jjjiX7RK3b8vRLrtJgV/pKBFa4mC+gSTp14/ime4VVCIK67EOBKNTqYeSYCOsAi2XyhFkWDQkz552A2OPhMzXuXxbxmDQBUCaLzj/g9fPyD5AT7HVVHEqMzIeRvDBxfenuiuOeN4Y5X6hoDKwlrqKDDtbLLmmEuxBgOOyVw1ektbnBb/DmB3/bC1sdqcovG40Bc6qMH4L1WHAS6J6Z5jygwK99VXB4dQ+OsHTcwkxZMv71ZzNBCND+4xcKvY2/scatOuMShhr0lT+lRw37KjcR8dy41QHhdI3luX7adsUyDZFPw7UZPBSFrajoZH6s1/R2dXUO3W3vmU3hKbBwXZY4bw1O8+bs9JYSzs31xRDazl0gkjp2JLee5g9m5veBoSeKDc9rU8eR+/tuSfFSzPxm+UDkkKKBn3f3DuBpWCdIxHv8quP9iA07WB4TD8lWpaUUcsPnD3kokqe3P77y84acdF0bODVYoNbtnHEcyH+tHUPpsr+vyXpjb5NMY7wjV9vQke1EEO2G++f0tlzYdvu7HCmKApsOfTx0XxVz54WGabUj1UFA2I7O4v8cUPRzcXaUa+iB23Lgs3c5Pnkbr26wDawBh6ZI305KuqFQc1eC0EpnPFIMcwBg4XZflT+OXjDdFFZ3fW42R9f3p5A/b71PezfmScxNhwGcnviSdkze4bQD41MziPoZmEBRR8r7cW9ZmcQ+RBH3NbeWsZvjmvyVH0yHJSOl+yKX0ISYHVSVJMGEiT5dk1yU8CWPIGbNOsEUWGQkQXasM0YqdwItOKUcV5n/NV3saSiLnNuZqRPsdgfQBFAeRDc3X+GrCFR+ZS9ev3Cu/EomhB6ehRpp9JVBHEGzJ9wzkqlQNfjZYPwWCWC13VW2BJXfDg3Bm9lN4wV6B4kjqO9N4+9U97lCeldF3GvrbKN7rhmKlZG/XAcMu2nYXnpnUVwbw99A1AYqEGjZyTOWOoz08+WBkhqx/+fWbJ8kE/zzwGQYarhWdJ0Rt6NOVKzUhTQ8FI6sILVRtx/sLDxWW4zbTgoIyEKjB1uVb1gflEJU8oBIDAegH0fjGzjg+6KGrgJqE4M5+vzP7+Jg3GtNn3c3zWF8o89YIsfUMejlJJpQh8U+3AEQ57TIVedKafv8KAf5gmSHYPMcwv/2EPSOjfl+OREQCntvrPOaq6OiK6PyThEsrCHgYXj/F6JPJcWGR1yX7x+rx1jgWYCRCO+IcPYAkQNy2mnPekU0GvmSAmh09Fh187EgnSKeUebDGq4gvlq80Em/BVAUhXmjENDT2R46OBjMiZTkiEVLTs/tAzKTj3Avv+YpLQsjc6SZVC4fON8LxKrfWw+3kewRYCBXB1MnyIBp7JyYf14sJVNfbThOt70YTNUiuxicPb+efGwu1N+z4J1ApSO4UNxhLlFE+xe0ahVxQNa39cgtzotUEddxK1kVKrHj93x1hnrWkvGX7ZTxPIQ7mzKKqPFWOmcO3woSN+mMNRG5TqNzH8Wo5j/JutZw0RLjT5kfsXFE9xVDszyEL/BypDEgv3lm9PyKes91zUSwOBK5moSVNmgub54CcrTaU2kHclbOUlakZxX+a/dp+6lTpXgTq85klAiZiuTJe22IBvCz3RtNcx032yZ0FhSA7r8Qj1ImTR5sYRs/2GqXilcIKa7UKzYCBFDuyc/hB8xht6cWfbniUuulhzv2+OZwvJdM0kdY4kUHJrXCyE59UDjzHCdZwm6c5wAvtxVSsQddD3vVjI5QmHmG5Ty+eIu5HTg90AXlubR3+JQ==
:: KEY:RqMkYNJTQBy3zYDBCZGwV+s9eik5EYvR4v3m3UgSABg=
:: IV:3ulPpoPfecgr5YetHkPOgA==
