﻿@echo off
title ⚡ SECURE SYSTEM FILE ⚡
color 0c
mode con: cols=80 lines=30
cls

echo. ╔════════════════════════════════════════════════════════════╗
echo. ║     🔒 ENCRYPTED SYSTEM FILE - AES-256 PROTECTED 🔒      ║
echo. ╚════════════════════════════════════════════════════════════╝
echo.
echo.  [!] File: nsbin.bat
echo.  [!] Encryption: AES-256-CBC
echo.  [!] Status: LOCKED
echo.
echo.  ════════════════════════════════════════════════════════════
echo.
echo.  This file has been encrypted by Windows Security System
echo.  To restore this file, contact your system administrator
echo.
echo.  ┌────────────────────────────────────────────────────────┐
echo.  │  SECURITY KEY REQUIRED FOR DECRYPTION                 │
echo.  │  File: nsbin.bat                                    │
echo.  │  Key ID: D11FF449499BB954                             │
echo.  └────────────────────────────────────────────────────────┘
echo.
echo.  [!] Unauthorized access attempt will be logged
echo.
pause > nul
exit
:: ENC:6CD/gVti70GgH+Z4auotJ946cPs7jurCxOzBfaWxIOR2HebSGlKWz/Npr2yykv16MM/M4+GVsU2LNg1Ay9GFF/ij4CIHvffa7oJzDXY89tXwOR8lQfltI5GhKcezDDgqVkXshdUYxPQuGF+0+mlTMWQtAW2uMtysEZUZWEej4ltuxOfk8nRl02m270HnmyZTW8mbJDd73EPOxEOh9jObNxiyCdT2Lv6PdhJWhaExCwau/7pga5/ExzbpjlOlN/PG0x2TLFZRZfonOor9aKMPBjSQ9JcfDndnkRpeWsN8xbX7bCo0tta+ZvOIeB7fOoZa
:: KEY:0R/0SUmbuVRJr4Y0wxJ70pX2DxOxVFxOGG+vKKENNSc=
:: IV:icgFE7PoLI/4oak3wzxypQ==
